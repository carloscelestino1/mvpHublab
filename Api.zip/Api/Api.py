import requests
import json

def buscar_dados():
    request = requests.get("http://127.0.0.1:8000/usuarios/usuarios/")
    dados = json.loads(request.content)
    print(dados)
    print()

def colocar_dados():
    play = {'email':'arthur@hotmail.com', 'senha':1234567}
    request = requests.post("http://127.0.0.1:8000/usuarios/usuarios/", data=play)
    print()

def deletar_dados(id):
    request = requests.delete("")
    print()

#buscar_dados()
colocar_dados()