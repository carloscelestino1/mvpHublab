from django.shortcuts import render
from .serializers import UsuariosSerializers
from .models import Usuarios
from rest_framework import viewsets

class UsuariosView(viewsets.ModelViewSet):
    queryset = Usuarios.objects.all()
    serializer_class = UsuariosSerializers